function toggleGabarito(botao) {
    var gabarito = botao.nextElementSibling;
    if (gabarito.style.display === "none") {
        gabarito.style.display = "block";
        botao.textContent = "Ocultar Resposta";
    } else {
        gabarito.style.display = "none";
        botao.textContent = "Mostrar Resposta";
    }
}